<?php
$id_money = $_REQUEST["id_money"];  
$date_time = $_REQUEST["date_time"];    
$description_money = $_REQUEST["description_money"];
$type_use = $_REQUEST["type_use"];
$amount = $_REQUEST["amount"];
$category = $_REQUEST["category"];

$update_sql = "UPDATE moneyrecord SET " .
              "date_time='" . $date_time . "'," . 
              "description_money='" . $description_money . "'," . 
              "type_use='" . $type_use . "'," .
              "amount='" . $amount . "'," .
              "category='" . $category . "' " .
              "WHERE id_money='" . $id_money . "'";
//echo $update_sql;

$conn = mysqli_connect("localhost", "root", "", "expense_tracker");
$rs = mysqli_query($conn, $update_sql);

echo "Update successful";
mysqli_close($conn);
?>