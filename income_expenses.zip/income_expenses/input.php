<?php

$id_money = $_REQUEST["id_money"];    
$date_time = $_REQUEST["date_time"];    
$description_money = $_REQUEST["description_money"];
$type_use = $_REQUEST["type_use"];
$amount = $_REQUEST["amount"];
$category = $_REQUEST["category"];

$sql = "INSERT INTO moneyrecord(id_money, date_time, description_money, type_use, amount, category)" . 
    " VALUES('$id_money', '$date_time', '$description_money', '$type_use', $amount, '$category')";

//connect database server
$conn = mysqli_connect("localhost", "root", "", "expense_tracker");

//execute sql command
mysqli_query($conn, "SET NAMES UTF8");
$result = mysqli_query($conn, $sql);

if ($result)
    echo "บันทึกข้อมูลสำเร็จ ";
else
    echo "ไม่สามารถบันทึกได้";

mysqli_close($conn);
?>
<a href="show_income.php">กลับไปยังหน้าหลัก</a>
