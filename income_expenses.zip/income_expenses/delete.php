<?php
$id_money = $_REQUEST["id_money"];

$Delete_sql = "DELETE FROM moneyrecord WHERE  id_money='".$id_money."'";
              

$conn = mysqli_connect("localhost", "root", "", "expense_tracker");
$rs = mysqli_query($conn, $Delete_sql);

echo "Delete successful";
mysqli_close($conn);
?>
<a href="show_income.php">กลับไปยังหน้าหลัก</a>