<?php
// ตั้งค่าการเชื่อมต่อฐานข้อมูล
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "expense_tracker";

$conn = new mysqli($servername, $username, $password, $dbname);

// ตรวจสอบการเชื่อมต่อ
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $category_name = $_POST['category_name'];

    // ตรวจสอบว่ามีชื่อหมวดหมู่หรือไม่
    if (!empty($category_name)) {
        // เพิ่มหมวดหมู่ใหม่
        $sql = "INSERT INTO category (category_name) VALUES ('$category_name')";
        
        if ($conn->query($sql) === TRUE) {
            echo "เพิ่มหมวดหมู่สำเร็จ";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
}

$conn->close();
?>
